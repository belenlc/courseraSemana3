package com.example.belenlc.mascotas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Detalle_mascota extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mascota_detalle);

        //para que funcione nuestro botón de subir en la gerarquía
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        // recibimos el intent

        Bundle parametros = getIntent().getExtras();


        //Declaramos nuestros textView de nuestro activity del detalle de la mascota

        TextView nombreDetalle  = (TextView) findViewById(R.id.nombreDetalle);
        TextView razaDetalle    = (TextView) findViewById(R.id.razaDetalle);
        TextView numFavDetalle  = (TextView) findViewById(R.id.contadorFavCV);

        //Colocamos a cada view los datos que traemos con el bundle del intent

    }
}
