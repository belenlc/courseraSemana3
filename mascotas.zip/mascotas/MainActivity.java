package com.example.belenlc.mascotas;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    //SwipeRefreshLayout SRefresh;
    //ListView lista;
    //Adapter adaptador;
    ArrayList <mascota> mascotasArray;
    private RecyclerView listaMascotas;
    View view1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //enlazamos con el xml
        setContentView(R.layout.activity_main);

        android.support.v7.widget.Toolbar miActionBar = (android.support.v7.widget.Toolbar) findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);


        //inicializamos datos y creamos/asociamos nuestro recyclerView

        listaMascotas = (RecyclerView) findViewById(R.id.RvMascota);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        //para que nuestro RV (lista contactos) se comporte como el linear Layout
        listaMascotas.setLayoutManager(llm);

        inicializarListaMascotas();
        inicializarAdaptador();



    }

    public void irATop5(View view){
        Intent intent = new Intent(this, Detalle_mascota.class);
        startActivity(intent);
    }

/*
    public void agregarFAB (){

        FloatingActionButton huesoBlanco=(FloatingActionButton)findViewById(R.id.FABhuesoBlanco);
        huesoBlanco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(getBaseContext(),getResources().getString(R.string.ToastFABhuesoB),Toast.LENGTH_SHORT).show();

                Snackbar.make(v,getResources().getString(R.string.ToastFABhuesoB),Snackbar.LENGTH_LONG)
                        .setAction(getResources().getString(R.string.AccionSnackBar), new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Log.i("Snackbar", "onClick: click en SnackBar");
                            }
                        })
                        .setActionTextColor(getResources().getColor(R.color.colorAccent))
                        .show();

            }
        });
    }
    */

    public void inicializarListaMascotas (){

        mascotasArray = new ArrayList <mascota>();

        mascotasArray.add(new mascota("Pipo", "Corgi",R.drawable.icons8_corgi_48,"0"));
        mascotasArray.add(new mascota("Kala", "Coker",R.drawable.icons8_perro_48,"0"));
        mascotasArray.add(new mascota("Bella", "Rodvailler",R.drawable.icons8_corgi_48,"0"));
        mascotasArray.add(new mascota("Prim", "San Bernardo",R.drawable.icons8_yorkshire_terrier_48,"0"));
        mascotasArray.add(new mascota("Beba", "Labrador",R.drawable.icons8_corgi_48,"0"));
        mascotasArray.add(new mascota("Nala", "YorkShire",R.drawable.icons8_yorkshire_terrier_48,"0"));
        mascotasArray.add(new mascota("Yuri", "hachicko",R.drawable.icons8_hachiko_48,"0"));
        mascotasArray.add(new mascota("Lexter", "carlino",R.drawable.icons8_perro_48,"0"));
        mascotasArray.add(new mascota("Bobo", "caniche",R.drawable.icons8_hachiko_48,"0"));

    }

    // el adaptador llama al cardview del layout, inicializa los datos y hace que funcione el recycler view
    public void inicializarAdaptador(){
        mascotaAdaptador adaptador = new mascotaAdaptador(mascotasArray, this);
        listaMascotas.setAdapter(adaptador);

    }



}
